##################################
Python Billomat API Client Library
##################################

by Gerold Penz 2014


=============
Version 0.1.1
=============

2014-10-26

- Tests with *urllib3*

- Connection-module added. It uses *urllib3* to connect to Billomat.

- Clients-module added.

- *http.Url* helper-class added

- Clients-search finished

- Now, all clients can requested (really all).


=============
Version 0.0.2
=============

2014-10-26

- Licenses added


=============
Version 0.0.1
=============

2014-10-26

- Initialy imported

